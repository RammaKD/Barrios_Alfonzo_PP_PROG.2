package zoologico;

import java.util.Objects;

public class Animal {
    private String nombre;
    private int edad;
    private double peso;
    private TipoDeDieta tipoDieta;
    

    public Animal(String nombre, int edad, double peso, TipoDeDieta tipoDieta) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.tipoDieta = tipoDieta;
    }
    
    public double getPeso(){
        return peso;
    }
    
    public TipoDeDieta getTipoDieta(){
        return tipoDieta;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, edad);
    }
    
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (o instanceof String str) {
            return str.equals(nombre);  // Compara con el nombre si el objeto es un String
        }
        if (o instanceof Animal a) {
            return nombre.equals(a.nombre) && edad == a.edad;  // Compara nombre y edad si es un Animal
        }
        return false;
}
    
    
    
}
