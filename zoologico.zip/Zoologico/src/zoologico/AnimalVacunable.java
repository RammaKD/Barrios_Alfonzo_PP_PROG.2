package zoologico;

public interface AnimalVacunable {
    void vacunar();
}
