package zoologico;

public enum TipoDeDieta {
    HERVIBORO,
    CARNIVORO,
    OMNIVORO
}
