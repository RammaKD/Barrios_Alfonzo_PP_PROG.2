package zoologico;

public class Mamifero extends Animal implements AnimalVacunable{
    public Mamifero(String nombre, int edad, double peso, TipoDeDieta tipoDieta){
        super(nombre, edad, peso, tipoDieta);
    }
    
    @Override
    public void vacunar(){
        System.out.println("Vacunacion mamifero hecha.");
    }
    
    @Override
    public String toString() {
        return "Mamifero" + "[" + "peso=" + super.getPeso() + ", " + "dieta=" + super.getTipoDieta() + "]";
    }
    
    
}
