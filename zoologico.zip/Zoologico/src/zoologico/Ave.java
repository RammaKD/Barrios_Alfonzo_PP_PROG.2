package zoologico;

public class Ave extends Animal implements AnimalVacunable{
   private double envergaduraAlas;
   
   public Ave(String nombre, int edad, double peso, TipoDeDieta tipoDieta, double envergaduraAlas){
        super(nombre, edad, peso, tipoDieta);
        this.envergaduraAlas = envergaduraAlas;
   }
   
   @Override
   public void vacunar(){
        System.out.println("Vacunacion ave hecha.");
   }
   
    @Override
    public String toString() {
        return "Ave" + "[" + "envergaduraAlas=" + envergaduraAlas +"]";
    }
}
