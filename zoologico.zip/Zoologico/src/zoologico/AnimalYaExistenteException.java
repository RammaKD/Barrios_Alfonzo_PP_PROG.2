package zoologico;

public class AnimalYaExistenteException extends RuntimeException{
        public final static String MESSAGE = "El animal ya existe en el zoologico";
    
    public AnimalYaExistenteException(){
        super(MESSAGE);
    }
}
