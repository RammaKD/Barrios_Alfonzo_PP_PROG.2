package zoologico;

import java.util.ArrayList;
import java.util.List;

public class Zoologico {
    private List<Animal> animales;
    
    public Zoologico(){
        animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal a) {
        if (animales.contains(a)) {
            throw new AnimalYaExistenteException();
        }
        if (a == null) {
            throw new NullPointerException();
        }
        animales.add(a);
    }
    
    public void mostrarAnimales(){
        if(!animales.isEmpty()){
            for(Animal a : animales){
                System.out.println(a);
            }
        } else {
            System.out.println("No hay animales en el zoo");
        }
    }
    
    public void vacunarAnimales() {
        for (Animal animal : animales) {
            if (animal instanceof AnimalVacunable) {
                ((AnimalVacunable) animal).vacunar();  
            } else {
                System.out.println("El animal " + animal.getNombre() + 
                        " no puede ser vacunado.");
            }
        }
    }
}