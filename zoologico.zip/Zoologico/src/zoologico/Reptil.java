package zoologico;

public class Reptil extends Animal{
    private String tipoDeEscama;
    private String regTemperatura;
    
    public Reptil(String nombre, int edad, double peso, TipoDeDieta tipoDieta,
            String tipoDeEscama, String regTemperatura){
        super(nombre, edad, peso, tipoDieta);
        this.tipoDeEscama = tipoDeEscama;
        this.regTemperatura = regTemperatura;
    }
    
    @Override
    public String toString() {
        return "Reptil" + "[" + "tipoEscama=" + tipoDeEscama + ", " + "regTemperatura=" +regTemperatura + "]";
    }
}
