package zoologico;

public class TestZoologico {

    public static void main(String[] args) {
        Animal a1 = new Mamifero("Pepe", 10, 10.7, TipoDeDieta.CARNIVORO);
        Animal a2 = new Reptil("Snake", 4, 2.5, TipoDeDieta.CARNIVORO, "Escama Dura", "Regulacion rapida");
        Animal a3 = new Mamifero("Julian", 10, 10.7, TipoDeDieta.OMNIVORO);
        Animal a4 = new Ave("Roco", 10, 10.7, TipoDeDieta.HERVIBORO, 100.8);
        Animal a5 = new Ave("Matias", 10, 10.7, TipoDeDieta.HERVIBORO, 105.7);
    
        Zoologico zoo1 = new Zoologico();
        
        try {
        zoo1.agregarAnimal(a1);
        zoo1.agregarAnimal(a2);
        zoo1.agregarAnimal(a1);
        zoo1.agregarAnimal(a4);
        zoo1.agregarAnimal(a5);
        }
         catch(NullPointerException ex){
            System.out.println("Me pasaste un null en lugar de un animal.");
         }
         catch(AnimalYaExistenteException ex){
             System.out.println(ex.getMessage());
         }
    
        System.out.println("------------------------------------------");
        zoo1.mostrarAnimales();
        System.out.println("------------------------------------------");
        zoo1.vacunarAnimales();
    
    }
    
}
